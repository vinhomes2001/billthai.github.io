<?php
    $tennguoinhan = $_POST["tennguoinhan"];
    $tennguoigui = $_POST["tennguoigui"];
    $stk = $_POST["stk"];
    $stknhan = $_POST["stknhan"];
    $sotienchuyen = $_POST["sotienchuyen"];
    $thoigianchuyen = $_POST["thoigianchuyen"];
    $mathamchieu = $_POST["mathamchieu"];
    $phoiBank = $_SERVER['DOCUMENT_ROOT'].'/scb//billtestkhach.jpg';
    $fontPath = $_SERVER['DOCUMENT_ROOT'].'/scb/';
    $image = imagecreatefromjpeg($phoiBank);
    if (!is_numeric($sotienchuyen)) {
        exit(JSON_FORMATTER(["status" => -1, "msg" => "Số tiền chuyển phải là một con số."]));
    }
    function canletrai($image, $fontsize, $y, $textColor, $font, $text, $x_tcb) {
        $fontSize = $fontsize;
        $lines = explode('<br>', $text);
        $lineHeight = $fontsize * 1.7;
        foreach ($lines as $i => $line) {
            $yOffset = $y + ($i * $lineHeight);
            imagettftext($image, (int)round($fontSize), 0, (int)round($x_tcb), (int)round($yOffset), $textColor, $font, $line);
        }
    }
    function canchinhphai($image, $fontsize, $y, $textColor, $font, $text, $customX = 50)
    {
        $fontSize = $fontsize;
        $textBoundingBox = imagettfbbox($fontSize, 0, $font, $text);
        $textWidth = $textBoundingBox[2] - $textBoundingBox[0];
        $imageWidth = imagesx($image);
        $x = $imageWidth - $textWidth - $customX;
        imagettftext($image, $fontSize, 0, $x, $y, $textColor, $font, $text);
    }
    function canbentren($image, $x, $y, $color, $fontPath, $text, $fontSize) {
        imagettftext($image, $fontSize, 0, $x, $y, $color, $fontPath, $text);
    }
    function maskStk($stk) {
    $stk = preg_replace('/\s+/', '', $stk);
    if (strlen($stk) <= 4) {
        return $stk;
    }
    $last3 = substr($stk, -4, 3); 
    $last1 = substr($stk, -1);   

    return "xxx-xxx{$last3}-{$last1}";
    }
    function canchinhgiua($image, $fontsize, $y, $textColor, $font, $text)
        {
            $fontSize = (int)$fontsize; 
            $textBoundingBox = imagettfbbox($fontSize, 0, $font, $text);
            $textWidth = $textBoundingBox[2] - $textBoundingBox[0];
            $imageWidth = imagesx($image);
            $x = (int)(($imageWidth - $textWidth) / 2); 
            $y = (int)$y;
            imagettftext($image, $fontSize, 0, $x, $y, $textColor, $font, $text);
        }
    $soTienFormat = number_format($sotienchuyen, 2, '.', ',');
    canchinhphai(
        $image,
        26,
        790,
        imagecolorallocate($image,0,0,0),
        $fontPath.'/static/SanFranciscoDisplay-Regular.otf',
        $soTienFormat
    );
    canchinhphai($image, 25, 612, imagecolorallocate($image, 10,9,8), $fontPath.'/static/PlaypenSansThai-Regular.ttf', $tennguoinhan);
    canchinhphai(
        $image, 
        21, 
        530, 
        imagecolorallocate($image,0,0,0), 
        $fontPath.'/static/SanFranciscoDisplay-Regular.otf', 
        maskStk($stk)  
    );
    canchinhphai(
        $image, 
        21, 
        660, 
        imagecolorallocate($image,0,0,0), 
        $fontPath.'/static/SanFranciscoDisplay-Regular.otf', 
        maskStk($stknhan)
    );
    canchinhphai($image, 25, 486, imagecolorallocate($image,10,9,8), $fontPath.'/static/NotoSansThai_SemiCondensed-Regular.ttf', $tennguoigui);
    canletrai($image, 18, 378, imagecolorallocate($image, 98,98,98), $fontPath.'/static/SanFranciscoDisplay-Regular.otf', $mathamchieu, 290);
    canchinhgiua($image, 21, 335, imagecolorallocate($image,98,98,98), $fontPath.'/static/NotoSansThai_SemiCondensed-Regular.ttf', $thoigianchuyen, 97);
    ob_start();
    imagepng($image);
    $imageData = ob_get_clean();
    $base64 = base64_encode($imageData);
    imagedestroy($image);
    echo $base64;
